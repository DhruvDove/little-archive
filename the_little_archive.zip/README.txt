THE LITTLE ARCHIVE

Open index.html in a browser.

How it works:
- Add memories with a date, title, text, and optional image.
- Memories are saved in that browser using localStorage.
- "Random memory" jumps to a random entry.
- "Export diary" creates a JSON backup.
- "Import diary" restores a backup.

Important:
This first version stores everything locally in the browser. If you send the HTML file to your friend, her copy will NOT automatically receive future entries you add.

For a true shared/updatable version, the next step is to put the diary behind a small hosted database or a private content service. Then you can update entries and she can see the changes from any device.
